# csc411_assignment6

- Identifies you and your programming partner by name

Sam Calise and Claudia deverdits

– Acknowledges help you may have received from or collaborative work you may have undertaken with others

We have recieved help from Vincent and Daniel from their TA help sessions

– Explains what routine in the final um takes up the most time, and says whether the assembly code could be improved and how

We believe that the load program function and the output is taking up the most time in our program. Our samply and flamegraph
was not working during this assingment so we relied on TA feedback from office hours and attempted to optimize our code. In doing 
so, We were able to make significant impact on our code's runtime based on Vincent and Daniel's help from later last week. If the assembly
code could improve the function to cache the find_instruction portion of this assignment. We believe our runtime could of improved significantly 
based on this revision of the compiler.

– Says approximately how many hours you have spent analyzing the problems posed in the assignment

~2-3hrs 

– Says approximately how many hours you have spent solving the problems after your analysis

~10-12hrs